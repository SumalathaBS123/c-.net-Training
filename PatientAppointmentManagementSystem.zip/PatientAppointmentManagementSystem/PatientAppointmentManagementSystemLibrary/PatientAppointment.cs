﻿using System;
using System.Collections.Generic;
using PatientAppointmentManagementSystemLibrary.SupportClass;
using PatientAppointmentManagementSystemLibrary.InfoClasses;


namespace PatientAppointmentManagementSystemLibrary
{
    public class PatientAppointment
    {
        public event EventHandler<DoctorInfo> AppointmentNotification;

        public void RegistrationDesk()
        {
            PatientAppointmentClass patientAppointment = new PatientAppointmentClass();

            var doctorList = patientAppointment.AddDoctor();
            patientAppointment.AddReceptionist();
            var patinetInfoList = patientAppointment.AddPatient();


            AppointmentNotification += SendSMSNotification;
            AppointmentNotification += SendMailNotification;

                Console.WriteLine("Welcome to registration \n");

                Console.WriteLine("Add the patient details here");
                Console.WriteLine("PatientID");
                string patientID = Console.ReadLine();
                Console.WriteLine("First Name");
                string firstName = Console.ReadLine();
                Console.WriteLine("Last Name");
                string lastName = Console.ReadLine();
                Console.WriteLine("Age");
                int age = Int32.Parse(Console.ReadLine());
                Console.WriteLine("Gender");
                string gender = Console.ReadLine();
                Console.WriteLine("Phone Number");
                string phoneNo = Console.ReadLine();
                Console.WriteLine("Address");
                string address = Console.ReadLine();
                Console.WriteLine("Health Problem (Ex: Fever, ENT, Cold, heart desease, Dental, Accident, Skin care, Cancer, Hair Loss");
                string healthIssue = Console.ReadLine();
                Console.WriteLine("Appointments will be given for present month");
                Console.WriteLine("Enter appointment date in yyyy, mm, dd format");
                DateTime expectedAppointmentDate = Convert.ToDateTime(Console.ReadLine());

                var department = SelectDepartment(healthIssue, age);
                var appointedDoctor = SelectDoctor(department, doctorList, expectedAppointmentDate);

                patinetInfoList.Add(new PatientInfo(firstName, lastName, patientID, age, gender, address, phoneNo, healthIssue, expectedAppointmentDate, appointedDoctor.FirstName, department));

            ViewOfDashboard dashBoardView = new ViewOfDashboard();
            dashBoardView.DashboardView(patinetInfoList);
        }

        public DepartmentInfo SelectDepartment(string healthIssue, int age)
        {
            DepartmentClassHelper assignDepartment = new DepartmentClassHelper();
            DepartmentInfo departmentSelected = assignDepartment.AssignToDepartment(healthIssue, age);
            return departmentSelected;
        }

        public DoctorInfo SelectDoctor(DepartmentInfo department, List<DoctorInfo> doctorList, DateTime appointmentDate)
        {
            DoctorClassHelper doctorClassHelper = new DoctorClassHelper();
            DoctorInfo doctorSelected = doctorClassHelper.AssignDoctor(department, doctorList, appointmentDate);
            Console.WriteLine("The Patient has been given Appointment with the Dr." + doctorSelected.FirstName + " of the " + department + " Department"+ " on "+ appointmentDate.ToString("d")+" "+ doctorSelected.WorkingShift);
            AppointmentNotification?.Invoke(this, doctorSelected);

            return doctorSelected;
        }

        public void SendSMSNotification(object sender, DoctorInfo doctor)
        {

            Console.WriteLine("SMS Notification sent");
        }

        public void SendMailNotification(object sender, DoctorInfo doctor)
        {
            
            Console.WriteLine(" Mail Notification sent");
        }
    }
}

