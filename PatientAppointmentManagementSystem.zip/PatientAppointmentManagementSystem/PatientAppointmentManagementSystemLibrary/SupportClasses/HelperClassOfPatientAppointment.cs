﻿using System;
using System.Collections.Generic;
using PatientAppointmentManagementSystemLibrary.InfoFolders;

namespace PatientAppointmentManagementSystemLibrary.SupportClasses{
    public class HelperClassOfPatientAppointment
    {
        public List<DoctorInfo> AddDoctor()
        {
            List<DoctorInfo> doctorInfoList = new List<DoctorInfo>();
            doctorInfoList.Add(new DoctorInfo("Asha", "Rani", "Bangalore", "1234", Department.Dentist, Shift.Morning, new DateTime(2020, 4, 30), new DateTime(2020, 5, 15)));
            doctorInfoList.Add(new DoctorInfo("Usha", "P", "Mangalore", "984567", Department.Dentist, Shift.Evening, new DateTime(2020, 5, 14), new DateTime(2020, 5, 31)));
            doctorInfoList.Add(new DoctorInfo("Ajay", "Patel", "Tumkur", "848900", Department.Dermatologist, Shift.Morning, new DateTime(2020, 4, 30), new DateTime(2020, 5, 31)));
            doctorInfoList.Add(new DoctorInfo("Bindu", "Shree", "Bagalkote", "688903", Department.Emergency, Shift.Morning, new DateTime(2020, 4, 30), new DateTime(2020, 5, 15)));
            doctorInfoList.Add(new DoctorInfo("Hima", "V", "Tumkur", "845880", Department.General_Physician, Shift.Morning, new DateTime(2020, 4, 30), new DateTime(2020, 5, 15)));
            doctorInfoList.Add(new DoctorInfo("Hema", "S", "Bellary", "249i0", Department.Oncology, Shift.Evening, new DateTime(2020, 4, 30), new DateTime(2020, 5, 31)));
            doctorInfoList.Add(new DoctorInfo("Ashok", "Patil", "Bangalore", "76999000", Department.Cardiology, Shift.Morning, new DateTime(2020, 4, 30), new DateTime(2020, 5, 31)));
            doctorInfoList.Add(new DoctorInfo("Ramya", "R", "Kolar", "346565", Department.Pediatrician, Shift.Morning, new DateTime(2020, 4, 30), new DateTime(2020, 5, 31)));
            doctorInfoList.Add(new DoctorInfo("Yogendra", "K", "Davanagere", "4565777", Department.General_Physician, Shift.Evening, new DateTime(2020, 5, 14), new DateTime(2020, 5, 31)));
            doctorInfoList.Add(new DoctorInfo("Rakesh", "A", "Kolar", "4753226", Department.Emergency, Shift.Night, new DateTime(2020, 5, 14), new DateTime(2020, 5, 31)));
            doctorInfoList.Add(new DoctorInfo("Deepak", "Naidu", "Bangalore", "5677888226", Department.ENT, Shift.Morning, new DateTime(2020, 4, 30), new DateTime(2020, 5, 31)));

            return doctorInfoList;

        }

        public List<Receptionist> AddReceptionist()
        {
            List<Receptionist> receptionistInfoList = new List<Receptionist>();
            receptionistInfoList.Add(new Receptionist("Meena", "Malivor", "Bangalore", "1268834", Shift.Morning));
            receptionistInfoList.Add(new Receptionist("Sharon", "Paul", "Tumkur", "84846900", Shift.Evening));
            receptionistInfoList.Add(new Receptionist("Jessica", "Potter", "Kolar", "476689536", Shift.Night));
            return receptionistInfoList;
        }

        public List<Patient> AddPatient()
        {
            List<Patient> PatientInfoList = new List<Patient>();
            PatientInfoList.Add(new Patient("Jhone", "Doe","156", 36, "M", "Bangalore", "6587990", "Skin Care", new DateTime(2020, 5, 3), "Ajay", Department.Dermatologist));
            PatientInfoList.Add(new Patient("Rama", "Nayak", "112", 56, "M", "Kolar", "6589670", "heart desease", new DateTime(2020, 5, 4), "Ashok", Department.Cardiology));
            PatientInfoList.Add(new Patient("Thilak", "M", "13", 28, "M", "Tumkur", "9463590", "Dental", new DateTime(2020, 5, 22), "Usha", Department.Dentist));
            PatientInfoList.Add(new Patient("Prakash", "P", "543", 45, "M", "Nelamangala", "745263590", "Accident", DateTime.Now, "Bindu", Department.Emergency));
            PatientInfoList.Add(new Patient("Rajat", "Rokade", "234", 20, "M", "Tumkur", "9668999", "ENT", new DateTime(2020, 5, 9), "Deepak", Department.ENT));
            PatientInfoList.Add(new Patient("Ramappa", "B R", "56", 65, "M", "Bagalkote", "3456590", "Cancer", new DateTime(2020, 5, 13), "Hema", Department.Oncology));
            PatientInfoList.Add(new Patient("Bindu", "Shree", "17", 10, "F", "Mysore", "785635", "Fever", new DateTime(2020, 5, 19), "Ramya", Department.Pediatrician));
            PatientInfoList.Add(new Patient("Veena", "Patil", "90", 32, "F", "Davanagere", "7996398", "Cold", new DateTime(2020, 5, 25), "Yogendra", Department.General_Physician));
            PatientInfoList.Add(new Patient("Ayush", "Kumari", "45", 49, "F", "Kolar", "454630", "Dental", new DateTime(2020, 5, 5), "Asha", Department.Dentist));
            PatientInfoList.Add(new Patient("Raja", "Rathod", "675", 58, "M", "Kolar", "786347667", "Fever", new DateTime(2020, 5, 5), "Hima", Department.General_Physician));
            return PatientInfoList;
        }
    }
}
