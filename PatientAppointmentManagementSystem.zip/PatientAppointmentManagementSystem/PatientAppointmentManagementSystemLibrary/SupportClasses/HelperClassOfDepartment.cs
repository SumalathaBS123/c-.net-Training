﻿using PatientAppointmentManagementSystemLibrary.InfoFolders;
using System;

namespace PatientAppointmentManagementSystemLibrary.SupportClasses
{
    public class HelperClassOfDepartment
    {
        public Department AssignToDepartment(string sickness, int age)
        {          
            if (age <= 14)
            {
                return Department.Pediatrician;
            }
            else
            {
                if (sickness.Equals("Fever") || sickness.Equals("Cold"))
                {
                    return Department.General_Physician;
                }
                else if (sickness.Equals("Cancer"))
                {
                    return Department.Oncology;
                }
                else if (sickness.Equals("Skin care") || sickness.Equals("Hair Loss"))
                {
                    return Department.Dermatologist;
                }
                else if (sickness.Equals("heart desease"))
                {
                    return Department.Cardiology;
                }
                else if (sickness.Equals("Dental"))
                {
                    return Department.Dentist;
                }
                else if (sickness.Equals("ENT"))
                {
                    return Department.ENT;
                }
                else if (sickness.Equals("Accident") || sickness.Equals("Unconscious"))
                {
                    return Department.Emergency;
                }
                else
                {
                    return Department.General_Physician;
                }               
            }
        }
    }
}
