﻿using System;
using System.Collections.Generic;
using PatientAppointmentManagementSystemLibrary.InfoClasses;

namespace PatientAppointmentManagementSystemLibrary.SupportClass
{
    public class PatientAppointmentClass
    {
        public List<DoctorInfo> AddDoctor()
        {
            List<DoctorInfo> doctorInfoList = new List<DoctorInfo>();
            doctorInfoList.Add(new DoctorInfo("Ramya", "Rani", "Bangalore", "1234", DepartmentInfo.Dentist, Shift.Morning, new DateTime(2020, 4, 30), new DateTime(2020, 5, 15)));
            doctorInfoList.Add(new DoctorInfo("Jayashree", "P", "Mangalore", "984567", DepartmentInfo.Dentist, Shift.Evening, new DateTime(2020, 5, 14), new DateTime(2020, 5, 31)));
            doctorInfoList.Add(new DoctorInfo("UMA", "Patel", "Tumkur", "848900", DepartmentInfo.Dermatologist, Shift.Morning, new DateTime(2020, 4, 30), new DateTime(2020, 5, 31)));
            doctorInfoList.Add(new DoctorInfo("Raj", "Shree", "Bagalkote", "688903", DepartmentInfo.Emergency, Shift.Morning, new DateTime(2020, 4, 30), new DateTime(2020, 5, 15)));
            doctorInfoList.Add(new DoctorInfo("Soumya", "V", "Tumkur", "845880", DepartmentInfo.General_Physician, Shift.Morning, new DateTime(2020, 4, 30), new DateTime(2020, 5, 15)));
            doctorInfoList.Add(new DoctorInfo("Ramya", "S", "Bellary", "249i0", DepartmentInfo.Oncology, Shift.Evening, new DateTime(2020, 4, 30), new DateTime(2020, 5, 31)));
            doctorInfoList.Add(new DoctorInfo("Ashok", "Patil", "Bangalore", "76999000", DepartmentInfo.Cardiology, Shift.Morning, new DateTime(2020, 4, 30), new DateTime(2020, 5, 31)));
            doctorInfoList.Add(new DoctorInfo("Ramya", "R", "Kolar", "346565", DepartmentInfo.Pediatrician, Shift.Morning, new DateTime(2020, 4, 30), new DateTime(2020, 5, 31)));
            doctorInfoList.Add(new DoctorInfo("Yogendra", "K", "Davanagere", "4565777", DepartmentInfo.General_Physician, Shift.Evening, new DateTime(2020, 5, 14), new DateTime(2020, 5, 31)));
            doctorInfoList.Add(new DoctorInfo("KArthik", "A", "Kolar", "4753226", DepartmentInfo.Emergency, Shift.Night, new DateTime(2020, 5, 14), new DateTime(2020, 5, 31)));
            doctorInfoList.Add(new DoctorInfo("Yogesh", "Naidu", "Bangalore", "5677888226", DepartmentInfo.ENT, Shift.Morning, new DateTime(2020, 4, 30), new DateTime(2020, 5, 31)));

            return doctorInfoList;

        }

        public List<ReceptionistInfo> AddReceptionist()
        {
            List<ReceptionistInfo> receptionistInfoList = new List<ReceptionistInfo>();
            receptionistInfoList.Add(new ReceptionistInfo("Kavya", "Malivor", "Bangalore", "1268834", Shift.Morning));
            receptionistInfoList.Add(new ReceptionistInfo("Sharma", "Paul", "Tumkur", "84846900", Shift.Evening));
            receptionistInfoList.Add(new ReceptionistInfo("Rajesh", "Potter", "Kolar", "476689536", Shift.Night));
            return receptionistInfoList;
        }

        public List<PatientInfo> AddPatient()
        {
            List<PatientInfo> PatientInfoList = new List<PatientInfo>();
            PatientInfoList.Add(new PatientInfo("Raj", "Doe","156", 36, "M", "Bangalore", "6587990", "Skin Care", new DateTime(2020, 5, 3), "Ajay", DepartmentInfo.Dermatologist));
            PatientInfoList.Add(new PatientInfo("Shilpa", "Nayak", "112", 56, "M", "Kolar", "6589670", "heart desease", new DateTime(2020, 5, 4), "Ashok", DepartmentInfo.Cardiology));
            PatientInfoList.Add(new PatientInfo("Kavya", "M", "13", 28, "M", "Tumkur", "9463590", "Dental", new DateTime(2020, 5, 22), "Usha", DepartmentInfo.Dentist));
            PatientInfoList.Add(new PatientInfo("Prakash", "P", "543", 45, "M", "Nelamangala", "745263590", "Accident", DateTime.Now, "Bindu", DepartmentInfo.Emergency));
            PatientInfoList.Add(new PatientInfo("Rajat", "Rokade", "234", 20, "M", "Tumkur", "9668999", "ENT", new DateTime(2020, 5, 9), "Deepak", DepartmentInfo.ENT));
           
            return PatientInfoList;
        }
    }
}
