﻿using PatientAppointmentManagementSystemLibrary.InfoFolders;
using System;
using System.Collections.Generic;
using System.Linq;

namespace PatientAppointmentManagementSystemLibrary
{
    public class DashBoard
    {
        public void DashboardView(List<Patient> registeredPatients)
        {

            Console.WriteLine("Welcome To The Hospital Dashboard \n");

            Console.WriteLine("Enter date in  format mentioned yyyy, mm, dd to view for Datewise appointment list \n");
            DateTime date = Convert.ToDateTime(Console.ReadLine());

            List<Patient> appointmentList = registeredPatients.Where(item => (item.ExpectedAppointment == date)).ToList();

            foreach (var item in appointmentList)
            {
                Console.WriteLine("Doctor: {0} -> Department: {1} -> Patient: {2}", item.DoctorAppointed, item.Department, item.FirstName);
            }

            if (appointmentList.Count <= 0)
            {
                Console.WriteLine("\n");
                Console.WriteLine("No appointments for the date: {0}", date.ToString("d"));
            }
        }
    }
}
