﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PatientAppointmentManagementSystemLibrary.InfoFolders
{ 
    public enum Department
    {
        General_Physician,       
        Emergency,
        ENT,
        Dentist,
        Pediatrician,
        Dermatologist,
        Oncology,
        Cardiology,
    }

    public enum Shift
    {
        Morning,
        Evening,
        Night
    }
}
