﻿using PatientAppointmentManagementSystemLibrary.Models;
using System;
using System.Collections.Generic;
using System.Linq;

namespace PatientAppointmentManagementSystemLibrary.HelperClass
{
    public class HelperClassOfDoctor
    {
        public Doctors AssignDoctor(Department department, List<Doctors> doctorList, DateTime appointmentDate)
        {
            if(department == Department.Cardiology)
            {
                var availableDoctor = doctorList.Where(item => (item.Specialization == Department.Cardiology) 
                                      && ((appointmentDate > item.AvailableDateFrom)
                                      && (appointmentDate < item.AvailableDateTo)))
                                      .FirstOrDefault();
                return availableDoctor;
            }

            if (department == Department.Dentist)
            {
                var availableDoctor = doctorList.Where(item => (item.Specialization == Department.Dentist)
                                      && ((appointmentDate > item.AvailableDateFrom)
                                      && (appointmentDate < item.AvailableDateTo)))
                                      .FirstOrDefault();
                return availableDoctor;
            }

            if (department == Department.Dermatologist)
            {
                var availableDoctor = doctorList.Where(item => (item.Specialization == Department.Dermatologist)
                                      && ((appointmentDate > item.AvailableDateFrom)
                                      && (appointmentDate < item.AvailableDateTo)))
                                      .FirstOrDefault();
                return availableDoctor;
            }

            if (department == Department.Emergency)
            {
                var availableDoctor = doctorList.Where(item => (item.Specialization == Department.Emergency)
                                      && ((DateTime.Now > item.AvailableDateFrom)
                                      && (DateTime.Now < item.AvailableDateTo)))
                                      .FirstOrDefault();
                return availableDoctor;
            }

            if (department == Department.Oncology)
            {
                var availableDoctor = doctorList.Where(item => (item.Specialization == Department.Oncology)
                                      && ((appointmentDate > item.AvailableDateFrom)
                                      && (appointmentDate < item.AvailableDateTo)))
                                      .FirstOrDefault();
                return availableDoctor;
            }

            if (department == Department.ENT)
            {
                var availableDoctor = doctorList.Where(item => (item.Specialization == Department.ENT)
                                      && ((appointmentDate > item.AvailableDateFrom)
                                      && (appointmentDate < item.AvailableDateTo)))
                                      .FirstOrDefault();
                return availableDoctor;
            }

            if (department == Department.Pediatrician)
            {
                var availableDoctor = doctorList.Where(item => (item.Specialization == Department.Pediatrician)
                                      && ((appointmentDate > item.AvailableDateFrom)
                                      && (appointmentDate < item.AvailableDateTo)))
                                      .FirstOrDefault();
                return availableDoctor;
            }

            if (department == Department.General_Physician)
            {
                var availableDoctor = doctorList.Where(item => (item.Specialization == Department.General_Physician)
                                      && ((appointmentDate > item.AvailableDateFrom)
                                      && (appointmentDate < item.AvailableDateTo)))
                                      .FirstOrDefault();
                return availableDoctor;
            }

            else
            {
                var availableDoctor = doctorList.Where(item => (item.Specialization == Department.General_Physician)
                      && ((appointmentDate > item.AvailableDateFrom)
                      && (appointmentDate < item.AvailableDateTo)))
                      .FirstOrDefault();
                return availableDoctor;
            }

        }
    }
}
