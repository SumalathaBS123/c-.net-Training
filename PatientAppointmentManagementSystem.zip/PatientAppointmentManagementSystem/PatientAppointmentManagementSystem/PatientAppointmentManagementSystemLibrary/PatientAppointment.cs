﻿using System;
using System.Collections.Generic;
using PatientAppointmentManagementSystemLibrary.HelperClass;
using PatientAppointmentManagementSystemLibrary.Models;


namespace PatientAppointmentManagementSystemLibrary
{
    public class PatientAppointment
    {
        public event EventHandler<Doctors> AppointmentNotification;

        public void RegistrationDesk()
        {
            HelperClassOfPAtientAppointment patientAppointmentHelper = new HelperClassOfPAtientAppointment();

            var doctorList = patientAppointmentHelper.AddDoctor();
            patientAppointmentHelper.AddReceptionist();
            var patinetInfoList = patientAppointmentHelper.AddPatient();


            AppointmentNotification += SendSMSNotification;
            AppointmentNotification += SendMailNotification;

                Console.WriteLine("WELCOME TO REGISTRATION DESK \n");

                Console.WriteLine("Add the patient details here");
                Console.WriteLine("PatientID");
                string patientID = Console.ReadLine();
                Console.WriteLine("First Name");
                string firstName = Console.ReadLine();
                Console.WriteLine("Last Name");
                string lastName = Console.ReadLine();
                Console.WriteLine("Age");
                int age = Int32.Parse(Console.ReadLine());
                Console.WriteLine("Gender");
                string gender = Console.ReadLine();
                Console.WriteLine("Phone Number");
                string phoneNo = Console.ReadLine();
                Console.WriteLine("Address");
                string address = Console.ReadLine();
                Console.WriteLine("Health Problem (Ex: Fever, ENT, Cold, heart desease, Dental, Accident, Skin care, Cancer, Hair Loss");
                string healthIssue = Console.ReadLine();
                Console.WriteLine("Appointments will be given only for current month");
                Console.WriteLine("Enter appointment date in yyyy, mm, dd format(In case of Emmergency enter today's date)");
                DateTime expectedAppointmentDate = Convert.ToDateTime(Console.ReadLine());

                var department = SelectDepartment(healthIssue, age);
                var appointedDoctor = SelectDoctor(department, doctorList, expectedAppointmentDate);

                patinetInfoList.Add(new Patients(firstName, lastName, patientID, age, gender, address, phoneNo, healthIssue, expectedAppointmentDate, appointedDoctor.FirstName, department));

            DashBoard dashBoardView = new DashBoard();
            dashBoardView.DashboardView(patinetInfoList);
        }

        public Department SelectDepartment(string healthIssue, int age)
        {
            DepartmentClassHelper assignDepartment = new DepartmentClassHelper();
            Department departmentSelected = assignDepartment.AssignToDepartment(healthIssue, age);
            return departmentSelected;
        }

        public Doctors SelectDoctor(Department department, List<Doctors> doctorList, DateTime appointmentDate)
        {
            HelperClassOfDoctor doctorClassHelper = new HelperClassOfDoctor();
            Doctors doctorSelected = doctorClassHelper.AssignDoctor(department, doctorList, appointmentDate);
            Console.WriteLine("\n");
            Console.WriteLine("The Patient has been given Appointment with the Dr." + doctorSelected.FirstName + " of the " + department + " Department"+ " on "+ appointmentDate.ToString("d")+" "+ doctorSelected.WorkingShift);
            AppointmentNotification?.Invoke(this, doctorSelected);

            return doctorSelected;
        }

        public void SendSMSNotification(object sender, Doctors doctor)
        {
            Console.WriteLine("\n");
            Console.WriteLine("SMS Notification send to doctor and patient");
        }

        public void SendMailNotification(object sender, Doctors doctor)
        {
            Console.WriteLine("\n");
            Console.WriteLine(" Mail Notification send to doctor and patient");
        }
    }
}

