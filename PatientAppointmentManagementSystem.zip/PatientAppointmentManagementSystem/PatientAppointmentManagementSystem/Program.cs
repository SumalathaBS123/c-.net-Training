﻿using System;
using PatientAppointmentManagementSystemLibrary;

namespace PatientAppointmentManagementSystem
{
    public class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("WELCOME\n");
            Console.WriteLine("Short Name:");
            string Name = Console.ReadLine();
            Console.WriteLine(Name +  ": \t Welcome to Chaitanya hospital\n");
            Console.WriteLine("Reach out to registration desk for appointment \n");
            PatientAppointment patientAppioment = new PatientAppointment();
            patientAppioment.RegistrationDesk();
            Console.ReadLine();

        }
    }
}
