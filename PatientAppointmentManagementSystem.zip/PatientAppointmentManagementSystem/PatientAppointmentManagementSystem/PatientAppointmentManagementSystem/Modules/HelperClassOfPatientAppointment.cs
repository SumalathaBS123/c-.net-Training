﻿namespace PatientAppointmentManagementSystem
{
    internal class HelperClassOfPatientAppointment
    {
        public HelperClassOfPatientAppointment()
        {
        }
    }
}